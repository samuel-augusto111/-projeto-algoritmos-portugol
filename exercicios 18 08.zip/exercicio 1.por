programa
{
	funcao inicio()
	{
		inteiro v[8]

		"para (;<inteiro> ;) {<i = 0; i < 8; i++>}"
			laco1 escreva("Digite o ", i + 1, "º número: ")
			leia "v[i]"
		}
         

		para (inteiro i = 0; i < 8; i++)
		{
			escreva v[i] * 2, "\n"
		}
		
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 180; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */