programa

 real notas[10]
real soma = 0.0
real media
inteiro cont = 0
inteiro i

// Laço 1: lê as notas e acumula a soma
para (i = 0; i < 10; i++) {
    leia(notas[i])
    soma = soma + notas[i]
}

// Calcula a média
media = soma / 10

// Laço 2: conta notas acima da média
para (i = 0; i < 10; i++) {
    se (notas[i] > media) {
        cont = cont + 1
    }
}

escreva("Média: ", media)
escreva("Notas acima da média: ", cont++
/* $$$ Portugol Studio $$$ 
 * 
 * Esta seção do arquivo guarda informações do Portugol Studio.
 * Você pode apagá-la se estiver utilizando outro editor.
 * 
 * @POSICAO-CURSOR = 430; 
 * @PONTOS-DE-PARADA = ;
 * @SIMBOLOS-INSPECIONADOS = ;
 * @FILTRO-ARVORE-TIPOS-DE-DADO = inteiro, real, logico, cadeia, caracter, vazio;
 * @FILTRO-ARVORE-TIPOS-DE-SIMBOLO = variavel, vetor, matriz, funcao;
 */